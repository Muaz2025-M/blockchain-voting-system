// app.js
const Web3 = require('web3');

// Load Hardhat-generated artifact and deployed address
const votingArtifacts = require('../../artifacts/contracts/Voting.sol/Voting.json');
const deployedAddresses = require('./deployedAddress.json');

window.App = {
  eventStart: function() { 
    // Request account access from MetaMask
    window.ethereum.request({ method: 'eth_requestAccounts' });

    // Initialize Web3 with the provider from MetaMask
    const web3 = new Web3(window.ethereum);

    // Get the deployed contract address from the JSON file
    const votingAddress = deployedAddresses.Voting;

    // Create a contract instance using the ABI and address
    const VotingContract = new web3.eth.Contract(votingArtifacts.abi, votingAddress);

    // Store contract instance and account globally for reuse
    window.App.VotingContract = VotingContract;
    window.App.account = window.ethereum.selectedAddress;

    // Display the user's account
    $("#accountAddress").html("Your Account: " + window.App.account);

    // Fetch the number of candidates
    VotingContract.methods.getCountCandidates().call().then(function(countCandidates) {
      $(document).ready(function() {
        // Add candidate button handler
        $('#addCandidate').click(function() {
          var nameCandidate = $('#name').val();
          var partyCandidate = $('#party').val();
          VotingContract.methods.addCandidate(nameCandidate, partyCandidate)
            .send({ from: window.App.account, gas: 100000, gasPrice: 1000 })
            .then(function(result) {
              console.log("Candidate added");
            });
        });   

        // Set voting dates button handler
        $('#addDate').click(function() {             
          var startDate = Date.parse(document.getElementById("startDate").value) / 1000;
          var endDate = Date.parse(document.getElementById("endDate").value) / 1000;
          VotingContract.methods.setDates(startDate, endDate)
            .send({ from: window.App.account, gas: 100000, gasPrice: 1000 })
            .then(function(rslt) { 
              console.log("tarihler verildi");
            });
        });     

        // Display voting dates
        VotingContract.methods.getDates().call().then(function(result) {
          var startDate = new Date(result[0] * 1000);
          var endDate = new Date(result[1] * 1000);
          $("#dates").text(startDate.toDateString("#DD#/#MM#/#YYYY#") + " - " + endDate.toDateString("#DD#/#MM#/#YYYY#"));
        }).catch(function(err) { 
          console.error("ERROR! " + err.message);
        });           
      });

      // Populate candidate list
      for (var i = 0; i < countCandidates; i++) {
        VotingContract.methods.getCandidate(i + 1).call().then(function(data) {
          var id = data[0];
          var name = data[1];
          var party = data[2];
          var voteCount = data[3];
          var viewCandidates = `<tr><td> <input class="form-check-input" type="radio" name="candidate" value="${id}" id="${id}">${name}</td><td>${party}</td><td>${voteCount}</td></tr>`;
          $("#boxCandidate").append(viewCandidates);
        });
      }

      // Check if the user has voted
      VotingContract.methods.checkVote().call({ from: window.App.account }).then(function(voted) {
        console.log("Has voted: " + voted);
        if (!voted) {
          $("#voteButton").attr("disabled", false);
        }
      });
    }).catch(function(err) { 
      console.error("ERROR! " + err.message);
    });
  },

  vote: function() {    
    var candidateID = $("input[name='candidate']:checked").val();
    if (!candidateID) {
      $("#msg").html("<p>Please vote for a candidate.</p>");
      return;
    }
    window.App.VotingContract.methods.vote(parseInt(candidateID))
      .send({ from: window.App.account, gas: 100000, gasPrice: 1000 })
      .then(function(result) {
        $("#voteButton").attr("disabled", true);
        $("#msg").html("<p>Voted</p>");
        window.location.reload(1);
      })
      .catch(function(err) { 
        console.error("ERROR! " + err.message);
      });
  }
};

// Initialize the app on page load
window.addEventListener("load", function() {
  if (typeof web3 !== "undefined") {
    console.warn("Using web3 detected from external source like MetaMask");
  } else {
    console.warn("No web3 detected. Falling back to http://localhost:8545. You should remove this fallback when you deploy live, as it's inherently insecure. Consider switching to MetaMask for deployment.");
    window.ethereum = new Web3(new Web3.providers.HttpProvider("http://127.0.0.1:8545"));
  }
  window.App.eventStart();
});